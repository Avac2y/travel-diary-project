# Travel Diary Backend

Node.js + Express 后端模板，包含用户登录、游记增删改查接口。