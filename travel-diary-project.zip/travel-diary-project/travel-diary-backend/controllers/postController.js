exports.getPosts = (req, res) => {
  res.json({ code: 0, data: [], message: 'Fetched all posts' });
};

exports.getPostById = (req, res) => {
  const { id } = req.params;
  res.json({ code: 0, data: { id }, message: 'Fetched post' });
};

exports.createPost = (req, res) => {
  const { title, content } = req.body;
  const images = req.files['images'] || [];
  const video = req.files['video'] ? req.files['video'][0] : null;
  res.json({ code: 0, message: 'Post created', data: { title, content, images, video } });
};

exports.updatePost = (req, res) => {
  const { id } = req.params;
  res.json({ code: 0, message: `Post ${id} updated.` });
};

exports.deletePost = (req, res) => {
  const { id } = req.params;
  res.json({ code: 0, message: `Post ${id} deleted.` });
};
