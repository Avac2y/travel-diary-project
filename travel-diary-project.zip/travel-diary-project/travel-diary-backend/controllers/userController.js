exports.login = (req, res) => {
  const { username, password } = req.body;
  // Dummy auth logic
  if (username === 'admin' && password === '123456') {
    return res.json({ code: 0, data: { token: 'fake-jwt-token' }, message: 'success' });
  }
  return res.status(401).json({ code: 1, message: 'Invalid credentials' });
};

exports.register = (req, res) => {
  const { username } = req.body;
  // Dummy register logic
  return res.json({ code: 0, message: `User ${username} registered.` });
};
