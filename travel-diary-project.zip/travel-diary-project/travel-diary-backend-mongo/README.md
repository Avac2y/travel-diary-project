# MongoDB Travel Diary Backend

Node.js + Express + MongoDB 实现的旅游日记后端服务。