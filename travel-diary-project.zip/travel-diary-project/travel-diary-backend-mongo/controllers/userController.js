const User = require('../models/User');

exports.login = async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username, password });
  if (!user) return res.status(401).json({ code: 1, message: 'Invalid credentials' });

  res.json({ code: 0, data: { user }, message: 'Login successful' });
};

exports.register = async (req, res) => {
  const { username, password, nickname } = req.body;
  const user = new User({ username, password, nickname });
  try {
    await user.save();
    res.json({ code: 0, message: 'User registered' });
  } catch (err) {
    res.status(400).json({ code: 1, message: 'Registration failed', error: err.message });
  }
};
