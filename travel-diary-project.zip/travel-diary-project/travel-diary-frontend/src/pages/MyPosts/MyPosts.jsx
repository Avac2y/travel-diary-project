function MyPosts() {
  return <div>My Posts Page</div>;
}
export default MyPosts;