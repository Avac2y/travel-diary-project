import axios from 'axios';

const request = axios.create({
  baseURL: 'http://localhost:3000/api',
  timeout: 5000,
});

request.interceptors.response.use(
  res => res.data,
  err => Promise.reject(err)
);

export default request;
