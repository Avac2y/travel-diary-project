import ArticleForm from "../../components/ArticleForm";
function Publish() {
  return <div>
    <ArticleForm />
  </div>;
}
export default Publish;