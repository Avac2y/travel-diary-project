import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './MyPosts.css';

const MyPosts = () => {
  const [posts, setPosts] = useState([]);
  const navigate = useNavigate();

  // 模拟获取帖子数据
  useEffect(() => {
    // 这里替换为实际的API调用
    const mockPosts = [
      {
        id: 1,
        title: '东京之旅',
        date: '2024-03-15',
        coverImage: 'https://picsum.photos/200/300',
        summary: '探索东京的繁华与宁静...',
        status: 'approved' // 'approved', 'pending', 'rejected'
      },
      {
        id: 2,
        title: '巴黎浪漫行',
        date: '2024-03-10',
        coverImage: 'https://picsum.photos/200/300',
        summary: '漫步在塞纳河畔...',
        status: 'pending'
      },
      {
        id: 3,
        title: '纽约之行',
        date: '2024-03-05',
        coverImage: 'https://picsum.photos/200/300',
        summary: '感受大苹果的魅力...',
        status: 'rejected'
      }
    ];
    setPosts(mockPosts);
  }, []);

  const handleEdit = (postId) => {
    navigate(`/edit-post/${postId}`);
  };

  const handleDelete = (postId) => {
    // 这里添加删除帖子的逻辑
    if (window.confirm('确定要删除这篇游记吗？')) {
      console.log('删除帖子:', postId);
      // 实际项目中这里应该调用API删除帖子
      setPosts(posts.filter(post => post.id !== postId));
    }
  };

  const handlePublish = (postId) => {
    // 这里添加发布帖子的逻辑
    console.log('发布帖子:', postId);
    // 实际项目中这里应该调用API发布帖子
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'approved':
        return '可编辑';
      case 'pending':
        return '待审核';
      case 'rejected':
        return '未通过';
      default:
        return '';
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case 'approved':
        return 'status-approved';
      case 'pending':
        return 'status-pending';
      case 'rejected':
        return 'status-rejected';
      default:
        return '';
    }
  };

  return (
    <div className="my-posts-container">
      <h1>我的游记</h1>
      <div className="posts-grid">
        {posts.map(post => (
          <div key={post.id} className="post-card">
            <div className="post-status">
              <span className={`status-badge ${getStatusClass(post.status)}`}>
                {getStatusText(post.status)}
              </span>
            </div>
            <div className="post-image">
              <img src={post.coverImage} alt={post.title} />
            </div>
            <div className="post-content">
              <h3>{post.title}</h3>
              <p className="post-date">{post.date}</p>
              <p className="post-summary">{post.summary}</p>
              <div className="post-actions">
                <button
                  className="action-button delete-button"
                  onClick={() => handleDelete(post.id)}
                >
                  删除
                </button>
                {post.status === 'approved' && (
                  <button
                    className="action-button edit-button"
                    onClick={() => handleEdit(post.id)}
                  >
                    编辑
                  </button>
                )}
                {post.status === 'rejected' && (
                  <button
                    className="action-button publish-button"
                    onClick={() => handlePublish(post.id)}
                  >
                    发布
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyPosts;