import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './EditPost.css';

const EditPost = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [post, setPost] = useState({
        title: '',
        content: '',
        coverImage: '',
        date: ''
    });

    useEffect(() => {
        // 这里替换为实际的API调用
        // 模拟获取帖子数据
        const mockPost = {
            id: id,
            title: '东京之旅',
            content: '这是一段详细的游记内容...',
            coverImage: 'https://picsum.photos/200/300',
            date: '2024-03-15'
        };
        setPost(mockPost);
    }, [id]);

    const handleSubmit = (e) => {
        e.preventDefault();
        // 这里添加保存帖子的逻辑
        console.log('保存帖子:', post);
        navigate('/myposts');
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setPost(prev => ({
            ...prev,
            [name]: value
        }));
    };

    return (
        <div className="edit-post-container">
            <h1>编辑游记</h1>
            <form onSubmit={handleSubmit} className="edit-form">
                <div className="form-group">
                    <label htmlFor="title">标题</label>
                    <input
                        type="text"
                        id="title"
                        name="title"
                        value={post.title}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="coverImage">封面图片URL</label>
                    <input
                        type="text"
                        id="coverImage"
                        name="coverImage"
                        value={post.coverImage}
                        onChange={handleChange}
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="date">日期</label>
                    <input
                        type="date"
                        id="date"
                        name="date"
                        value={post.date}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="content">内容</label>
                    <textarea
                        id="content"
                        name="content"
                        value={post.content}
                        onChange={handleChange}
                        rows="10"
                        required
                    />
                </div>

                <div className="form-actions">
                    <button type="button" onClick={() => navigate('/myposts')} className="cancel-button">
                        取消
                    </button>
                    <button type="submit" className="save-button">
                        保存
                    </button>
                </div>
            </form>
        </div>
    );
};

export default EditPost; 