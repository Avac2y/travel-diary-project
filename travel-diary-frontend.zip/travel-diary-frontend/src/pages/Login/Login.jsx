import React from 'react';
import { Form, Input, Button, Card, message } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useDispatch } from 'react-redux';
import logo from '../../assets/travel-icon.png';
import './Login.css';

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [form] = Form.useForm();

  const onFinish = (values) => {
    // 这里添加实际的登录逻辑
    console.log('登录信息:', values);
    dispatch(fetchLogin(values));
    message.success('登录成功！');
  };

  return (
    <div className="login-page">
      <div className="app-icon">
        <img src={logo} alt="Travel Diary" className="logo" />
      </div>
      <div className="login-wrapper">
        <Card className="login-card">
          <div className="login-header">
            <h2>旅行日记</h2>
            <p>记录你的每一次旅行</p>
          </div>
          <Form
            form={form}
            name="login"
            onFinish={onFinish}
            autoComplete="off"
            size="large"
            validateTrigger={"onBlur"}
          >
            <Form.Item
              name="mobile"
              rules={[{ required: true, message: '请输入用户名！' }]}
            >
              <Input
                prefix={<UserOutlined />}
                placeholder="用户名"
              />
            </Form.Item>

            <Form.Item
              name="code"
              rules={[{ required: true, message: '请输入密码！' }]}
            >
              <Input.Password
                prefix={<LockOutlined />}
                placeholder="密码"
              />
            </Form.Item>

            <Form.Item>
              <Button type="primary" htmlType="submit" block>
                登录
              </Button>
            </Form.Item>
          </Form>
        </Card>
      </div>
    </div>
  );
};

export default Login;
