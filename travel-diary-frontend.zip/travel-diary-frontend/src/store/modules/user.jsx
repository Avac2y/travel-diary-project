//用户相关的状态管理
import { createSlice } from '@reduxjs/toolkit';

const userStore = createSlice({
    name: 'user',
    initialState: {
        token: '',
    },
    reducers: {
        setToken: (state, action) => {
            state.token = action.payload;
        }
    }
})

const { setToken } = userStore.actions;

//获取reducer函数
const userReducer = userStore.reducer;
//封装异步代码
const fetchLogin = (loginForm) => {
    //发送异步请求
    return async (dispatch, getState) => {
        const res = await request.post('/authorizations', loginForm)
         //提交同步action进行token的存入
        dispatch(setToken(res.data.token))
    }
}

export { setToken, fetchLogin }

export default userReducer;



