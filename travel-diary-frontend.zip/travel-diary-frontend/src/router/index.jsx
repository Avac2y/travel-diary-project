import Login from "../pages/Login/Login";
import Home from "../pages/Home/Home";
import MyPosts from "../pages/MyPosts/MyPosts";
import Publish from "../pages/Publish/Publish";
import WrongPage from "../pages/404/404"
import { createBrowserRouter } from "react-router-dom";
const router=createBrowserRouter([
    {
        path:'/login',
        element:<Login />
    },
    {
        path:'/home',
        element:<Home />
    },
    {
        path:'/myposts',
        element:<MyPosts />
    },
    {
        path:'/publish',
        element:<Publish />
    },
    {
         path:'*',
         element:<WrongPage />
    }
   

])

export default router