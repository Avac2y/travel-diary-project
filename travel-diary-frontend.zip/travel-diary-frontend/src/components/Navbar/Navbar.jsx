import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Navbar.css';

const Navbar = () => {
    const location = useLocation();
    const { isAuthenticated } = useAuth();

    if (!isAuthenticated) {
        return null;
    }

    return (
        <nav className="navbar">
            <Link to="/" className={`nav-item ${location.pathname === '/' ? 'active' : ''}`}>
                <i className="nav-icon">🏠</i>
                <span className="nav-text">首页</span>
            </Link>
            <Link to="/myposts" className={`nav-item ${location.pathname === '/myposts' ? 'active' : ''}`}>
                <i className="nav-icon">📝</i>
                <span className="nav-text">我的帖子</span>
            </Link>
        </nav>
    );
};

export default Navbar; 