//统一导出请求方法
import request from './request'

export {
    request
}
