const Post = require('../models/Post');

exports.getPosts = async (req, res) => {
  const posts = await Post.find();
  res.json({ code: 0, data: posts, message: 'Fetched posts' });
};

exports.getPostById = async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ code: 1, message: 'Post not found' });
  res.json({ code: 0, data: post });
};

exports.createPost = async (req, res) => {
  const { title, content } = req.body;
  const images = (req.files['images'] || []).map(f => f.path);
  const video = req.files['video'] ? req.files['video'][0].path : '';

  const newPost = new Post({ title, content, images, video });
  await newPost.save();
  res.json({ code: 0, message: 'Post created' });
};

exports.updatePost = async (req, res) => {
  await Post.findByIdAndUpdate(req.params.id, req.body);
  res.json({ code: 0, message: 'Post updated' });
};

exports.deletePost = async (req, res) => {
  await Post.findByIdAndDelete(req.params.id);
  res.json({ code: 0, message: 'Post deleted' });
};
