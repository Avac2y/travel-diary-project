import React from 'react';
import request from '../../services/request';

function ReviewCard({ post, onUpdate }) {
  const userRole = localStorage.getItem('role') || 'auditor';

  const handleApprove = () => {
    request.put(`/posts/${post._id}`, { status: 'approved' }).then(onUpdate);
  };

  const handleReject = () => {
    const reason = prompt('请输入拒绝理由');
    if (reason) {
      request.put(`/posts/${post._id}`, { status: 'rejected', rejectReason: reason }).then(onUpdate);
    }
  };

  const handleDelete = () => {
    request.delete(`/posts/${post._id}`).then(onUpdate);
  };

  return (
    <div className="review-card">
      <div className="card-left">
        <img src={post.images?.[0]} alt="preview" />
        <div>
          <h3>{post.title}</h3>
          <p>{post.content.slice(0, 100)}...</p>
        </div>
      </div>
      <div className="card-right">
        <span className={`status ${post.status}`}>{statusLabel(post.status)}</span>
        {(userRole === 'admin' || userRole === 'auditor') && <button onClick={handleApprove}>通过</button>}
        {(userRole === 'admin' || userRole === 'auditor') && <button onClick={handleReject}>拒绝</button>}
        {userRole === 'admin' && <button onClick={handleDelete}>删除</button>}
      </div>
    </div>
  );
}

function statusLabel(status) {
  switch (status) {
    case 'pending': return '待审核';
    case 'approved': return '已通过';
    case 'rejected': return '未通过';
    default: return '';
  }
}

export default ReviewCard;
