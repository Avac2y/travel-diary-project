import React, { useEffect, useState } from 'react';
import request from '../../services/request';
import ReviewCard from './ReviewCard';
import './review.css';

function PCReview() {
  const [posts, setPosts] = useState([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 5;


  useEffect(() => {
    request.get('/posts').then(res => {
   //   console.log('全部数据：', res.data.map(p => ({ title: p.title, status: p.status })));
      setPosts(res.data);
    });
  }, []);
  
  

  const fetchData = () => {
    request.get('/posts').then(res => {
      setPosts(res.data.reverse()); // 最新的在前
    });
  };

  const filtered = posts.filter(post =>
    (statusFilter === 'all' || post.status === statusFilter) &&
    (post.title.includes(searchKeyword) || post.author?.nickname.includes(searchKeyword))
  );
  // const filtered = posts;  // 暂时直接全部展示


  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  const totalPages = Math.ceil(filtered.length / pageSize);

  return (
    <div className="pc-review">
      <div className="search-bar">
        <input
          placeholder="目的地/酒店名"
          value={searchKeyword}
          onChange={e => setSearchKeyword(e.target.value)}
        />
        <button>搜索</button>
      </div>
      <div className="filter-buttons">
        {['所有', '已批准', '已拒绝', '待审核'].map(st =>
          <button
            key={st}
            onClick={() => setStatusFilter(st)}
            className={statusFilter === st ? 'active' : ''}
          >
            {st}
          </button>
        )}
      </div>
      <div className="post-list">
        {paginated.map(post => (
          <ReviewCard key={post._id} post={post} onUpdate={fetchData} />
        ))}
      </div>
      <div className="pagination">
        {Array.from({ length: totalPages }, (_, i) => (
          <button key={i} onClick={() => setCurrentPage(i + 1)} className={currentPage === i + 1 ? 'active' : ''}>
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
}

export default PCReview;
