import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import users from './users.json';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      localStorage.setItem('role', user.role);
      localStorage.setItem('username', user.username);
      alert('登录成功，欢迎 ' + user.username);
      navigate('/admin/review');
    } else {
      alert('用户名或密码错误');
    }
  };

  return (
    <div style={{ padding: 40 }}>
      <h2>登录系统</h2>
      <input placeholder="用户名" value={username} onChange={e => setUsername(e.target.value)} /><br/><br/>
      <input placeholder="密码" type="password" value={password} onChange={e => setPassword(e.target.value)} /><br/><br/>
      <button onClick={handleLogin}>登录</button>
    </div>
  );
}

export default Login;
