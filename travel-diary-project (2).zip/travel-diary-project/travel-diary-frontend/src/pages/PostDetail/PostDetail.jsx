function PostDetail() {
  return <div>Post Detail Page</div>;
}
export default PostDetail;